CHANNEL_ID = 'rocketbeanstv'
LETS_PLAY_CHANNEL_ID = 'UCtSP1OA6jO4quIGLae7Fb4g'
GUIDE_URL = 'http://api.rbtv.rodney.io/api/1.0/schedule/schedule_linear.json'
